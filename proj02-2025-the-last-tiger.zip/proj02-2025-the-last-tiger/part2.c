#include <stdio.h> // for stderr
#include <stdlib.h> // for exit()
#include "types.h"
#include "utils.h"
#include "riscv.h"


// forward declarations
void execute_rtype(Instruction, Processor *);
void execute_itype_except_load(Instruction, Processor *);
void execute_branch(Instruction, Processor *);
void execute_jalr(Instruction, Processor *);
void execute_jal(Instruction, Processor *);
void execute_load(Instruction, Processor *, Byte *);
void execute_store(Instruction, Processor *, Byte *);
void execute_ecall(Processor *, Byte *);
void execute_auipc(Instruction, Processor *);
void execute_lui(Instruction, Processor *);


void execute_instruction(Instruction instruction,Processor *processor,Byte *memory) {
  switch(instruction.opcode) {
    case 0x33: execute_rtype(instruction, processor); break;
    case 0x13: execute_itype_except_load(instruction, processor); break;
    case 0x03: execute_load(instruction, processor, memory); break;
    case 0x23: execute_store(instruction, processor, memory); break;
    case 0x63: execute_branch(instruction, processor); break;
    case 0x6F: execute_jal(instruction, processor); break;
    case 0x67: execute_jalr(instruction, processor); break;
    case 0x73: execute_ecall(processor, memory); break;
    case 0x17: execute_auipc(instruction, processor); break;
    case 0x37: execute_lui(instruction, processor); break;
    default:
      handle_invalid_instruction(instruction);
      exit(-1);
      break;
  }
  processor->pc += 4;
}


void execute_rtype(Instruction instruction, Processor *processor) {
  int rs1 = processor->R[instruction.rtype.rs1];
  int rs2 = processor->R[instruction.rtype.rs2];
  int *rd = &processor->R[instruction.rtype.rd];
  
  switch(instruction.rtype.funct3) {
    case 0x0:
      if (instruction.rtype.funct7 == 0x00) *rd = rs1 + rs2;
      else if (instruction.rtype.funct7 == 0x20) *rd = rs1 - rs2;
      break;
    case 0x1: *rd = rs1 << (rs2 & 0x1F); break;
    case 0x2: *rd = (rs1 < rs2) ? 1 : 0; break;
    case 0x4: *rd = rs1 ^ rs2; break;
    case 0x5:
      if (instruction.rtype.funct7 == 0x00) *rd = (unsigned)rs1 >> (rs2 & 0x1F);
      else if (instruction.rtype.funct7 == 0x20) *rd = rs1 >> (rs2 & 0x1F);
      break;
    case 0x6: *rd = rs1 | rs2; break;
    case 0x7: *rd = rs1 & rs2; break;
    default:
      handle_invalid_instruction(instruction);
      exit(-1);
  }
}


void execute_itype_except_load(Instruction instruction, Processor *processor) {
  int rs1 = processor->R[instruction.itype.rs1];
  int imm = instruction.itype.imm;
  int *rd = &processor->R[instruction.itype.rd];

  switch (instruction.itype.funct3) {
    case 0x0: *rd = rs1 + imm; break;
    case 0x2: *rd = (rs1 < imm) ? 1 : 0; break;
    case 0x4: *rd = rs1 ^ imm; break;
    case 0x6: *rd = rs1 | imm; break;
    case 0x7: *rd = rs1 & imm; break;
    case 0x1: *rd = rs1 << (imm & 0x1F); break;
    case 0x5:
      if ((imm >> 10) & 1) *rd = rs1 >> (imm & 0x1F);  // SRAI
      else *rd = (unsigned)rs1 >> (imm & 0x1F);        // SRLI
      break;
    default:
      handle_invalid_instruction(instruction);
  }
}


void execute_ecall(Processor *p, Byte *memory) {
  switch(p->R[17]) {
    case 10:
      exit(0);
      break;
    default:
      printf("Illegal ecall number %d\n", p->R[17]);
      exit(-1);
  }
}


void execute_branch(Instruction instruction, Processor *processor) {
  int rs1 = processor->R[instruction.sbtype.rs1];
  int rs2 = processor->R[instruction.sbtype.rs2];
  int offset = instruction.sbtype.imm;

  switch(instruction.sbtype.funct3) {
    case 0x0: if (rs1 == rs2) processor->pc += offset - 4; break;
    case 0x1: if (rs1 != rs2) processor->pc += offset - 4; break;
    case 0x4: if (rs1 < rs2) processor->pc += offset - 4; break;
    case 0x5: if (rs1 >= rs2) processor->pc += offset - 4; break;
    default:
      handle_invalid_instruction(instruction);
      exit(-1);
  }
}


void execute_load(Instruction instruction, Processor *processor, Byte *memory) {
  Address addr = processor->R[instruction.itype.rs1] + instruction.itype.imm;
  int *rd = &processor->R[instruction.itype.rd];

  switch(instruction.itype.funct3) {
    case 0x0: *rd = load(memory, addr, LENGTH_BYTE, 0); break;
    case 0x1: *rd = load(memory, addr, LENGTH_HALF_WORD, 0); break;
    case 0x2: *rd = load(memory, addr, LENGTH_WORD, 0); break;
    default:
      handle_invalid_instruction(instruction);
  }
}


void execute_store(Instruction instruction, Processor *processor, Byte *memory) {
  Address addr = processor->R[instruction.stype.rs1] + instruction.stype.imm;
  int value = processor->R[instruction.stype.rs2];

  switch(instruction.stype.funct3) {
    case 0x0: store(memory, addr, LENGTH_BYTE, value, 0); break;
    case 0x1: store(memory, addr, LENGTH_HALF_WORD, value, 0); break;
    case 0x2: store(memory, addr, LENGTH_WORD, value, 0); break;
    default:
      handle_invalid_instruction(instruction);
      exit(-1);
  }
}


void execute_jalr(Instruction instruction, Processor *processor) {
  int next_pc = processor->pc + 4;
  processor->pc = (processor->R[instruction.itype.rs1] + instruction.itype.imm) & ~1;
  processor->R[instruction.itype.rd] = next_pc;
}


void execute_jal(Instruction instruction, Processor *processor) {
  processor->R[instruction.ujtype.rd] = processor->pc + 4;
  processor->pc += instruction.ujtype.imm - 4;
}


void execute_auipc(Instruction instruction, Processor *processor) {
  processor->R[instruction.utype.rd] = processor->pc + instruction.utype.imm;
}


void execute_lui(Instruction instruction, Processor *processor) {
  processor->R[instruction.utype.rd] = instruction.utype.imm;
}


void store(Byte *memory, Address address, Alignment alignment, Word value, int check_align) {
  if ((check_align && !check(address,alignment)) || (address >= MEMORY_SPACE)) {
    handle_invalid_write(address);
  }

  switch (alignment) {
    case LENGTH_BYTE:
      memory[address] = value & 0xFF;
      break;
    case LENGTH_HALF_WORD:
      memory[address] = value & 0xFF;
      memory[address + 1] = (value >> 8) & 0xFF;
      break;
    case LENGTH_WORD:
      memory[address] = value & 0xFF;
      memory[address + 1] = (value >> 8) & 0xFF;
      memory[address + 2] = (value >> 16) & 0xFF;
      memory[address + 3] = (value >> 24) & 0xFF;
      break;
  }
}


Word load(Byte *memory, Address address, Alignment alignment, int check_align) {
  if ((check_align && !check(address,alignment)) || (address >= MEMORY_SPACE)) {
    handle_invalid_read(address);
  }

  Word value = 0;
  switch (alignment) {
    case LENGTH_BYTE:
      value = memory[address];
      break;
    case LENGTH_HALF_WORD:
      value = memory[address] | (memory[address + 1] << 8);
      break;
    case LENGTH_WORD:
      value = memory[address] |
              (memory[address + 1] << 8) |
              (memory[address + 2] << 16) |
              (memory[address + 3] << 24);
      break;
  }
  return value;
}